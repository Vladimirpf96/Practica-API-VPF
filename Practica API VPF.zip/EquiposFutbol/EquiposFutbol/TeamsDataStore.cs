﻿using EquiposFutbol.Entities;
using EquiposFutbol.Models;


namespace EquiposFutbol
{
    public class TeamsDataStore
    {
        public List<TeamDto> Teams { get; set; }
        public static TeamsDataStore Current { get; } = new TeamsDataStore();

        public TeamsDataStore()
        {
            Teams = new List<TeamDto>()
            {
                new TeamDto()
                {
                    Id = 1,
                    Name = "Real Madrid",
                    Players = new List<PlayerDto>()
                    {
                        new PlayerDto()
                        {
                            Id = 1,
                            Name = "Courtois",
                            Description = "Portero Belga, internacional con su país,heroe en la 14"
                        }
                    }
                },
                new TeamDto()
                {
                    Id = 2,
                    Name = "FC Barcelona",
                    Players = new List<PlayerDto>()
                    {
                        new PlayerDto()
                        {
                            Id = 2,
                            Name = "Pedri",
                            Description = "Joven jugador canario, estrella del equipo"
                        }
                    }
                }
            };

        }
    }
}


