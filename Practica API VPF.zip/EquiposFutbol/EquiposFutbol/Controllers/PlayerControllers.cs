﻿using AutoMapper;
using EquiposFutbol.Services;
using EquiposFutbol.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.JsonPatch;

namespace EquiposFutbol.Controllers
{
    [Route("api/teams/{teamID}/players")]
    [ApiController]
    public class PlayerControllers : ControllerBase
    {
        private readonly ILogger<PlayerControllers> _logger;
        private readonly ITeamInfoRepository _teamInfoRepository;
        private readonly IMapper _mapper;

        public PlayerControllers(ILogger<PlayerControllers> logger,
            ITeamInfoRepository teamInfoRepository,
            IMapper mapper)
        {
            _logger = logger ??
                throw new ArgumentNullException(nameof(logger));
            _teamInfoRepository = teamInfoRepository ??
                throw new ArgumentNullException(nameof(teamInfoRepository));
            _mapper = mapper ??
                throw new ArgumentNullException(nameof(mapper));
        }


        [HttpGet]
        public async Task<ActionResult<IEnumerable<PlayerDto>>> GetPlayer(
            int teamId)
        {

            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                _logger.LogInformation(
                    $"Team with id {teamId} wasn't found when accessing players.");
                return NotFound();
            }

            var playersforTeam = await _teamInfoRepository.GetPlayerforTeamAsync(teamId);

            return Ok(_mapper.Map<IEnumerable<PlayerDto>>(playersforTeam));
        }

        [HttpGet("{playerid}", Name = "GetPlayer")]
        public async Task<ActionResult<PlayerDto>> GetPlayer(
            int teamId, int playerId)
        {
            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                return NotFound();
            }

            var player = await _teamInfoRepository
                .GetPlayerforTeamAsync(teamId, playerId);

            if (player == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<PlayerDto>(player));
        }

        [HttpPost]
        public async Task<ActionResult<PlayerDto>> CreatePlayer(
           int teamId,PlayerforCreation player)
        {
            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                return NotFound();
            }

            var finalPlayer = _mapper.Map<Entities.Player>(player);

            await _teamInfoRepository.AddPlayerforTeamAsync(
                teamId, finalPlayer);

            await _teamInfoRepository.SaveChangesAsync();

            var createdPlayerToReturn =
                _mapper.Map<Models.PlayerDto>(finalPlayer);

            return CreatedAtRoute("GetPlayer",
                 new
                 {
                     teamId = teamId,
                     playerId = createdPlayerToReturn.Id
                 }, 
                 createdPlayerToReturn);
        }

        [HttpPut("{playerid}")]
        public async Task<ActionResult> UpdatePlayer(int teamId, int playerId,
            PlayerforUpdate player)
        {
            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                return NotFound();
            }

            var playerEntity = await _teamInfoRepository
                .GetPlayerforTeamAsync(teamId, playerId);
            if (playerEntity == null)
            {
                return NotFound();
            }

            _mapper.Map(player, playerEntity);

            await _teamInfoRepository.SaveChangesAsync();

            return NoContent();
        }


        [HttpPatch("{playerid}")]
        public async Task<ActionResult> PartiallyUpdatePlayer(
            int teamId, int playerId,
            JsonPatchDocument<PlayerforUpdate> patchDocument)
        {
            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                return NotFound();
            }

            var playerEntity = await _teamInfoRepository
                .GetPlayerforTeamAsync(teamId, playerId);
            if (playerEntity == null)
            {
                return NotFound();
            }

            var playerToPatch = _mapper.Map<PlayerforUpdate>(
                playerEntity);

            patchDocument.ApplyTo(playerToPatch, ModelState);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            if (!TryValidateModel(playerToPatch))
            {
                return BadRequest(ModelState);
            }

            _mapper.Map(playerToPatch, playerEntity);
            await _teamInfoRepository.SaveChangesAsync();

            return NoContent();
        }

        [HttpDelete("{playerid}")]
        public async Task<ActionResult> DeletePlayer(
            int teamId, int playerId)
        {
            if (!await _teamInfoRepository.TeamExistsAsync(teamId))
            {
                return NotFound();
            }

            var playerEntity = await _teamInfoRepository
                .GetPlayerforTeamAsync(teamId, playerId);
            if (playerEntity == null)
            {
                return NotFound();
            }

            _teamInfoRepository.DeletePlayer(playerEntity);
            await _teamInfoRepository.SaveChangesAsync();


            return NoContent();
        }


    }
}
