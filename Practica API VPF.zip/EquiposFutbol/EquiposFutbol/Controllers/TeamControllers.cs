﻿using Microsoft.AspNetCore.Mvc;

namespace EquiposFutbol.Controllers
{

    [ApiController]
    public class TeamControllers :ControllerBase
    {
    }
}
