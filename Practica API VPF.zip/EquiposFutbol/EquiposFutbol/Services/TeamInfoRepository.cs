﻿using EquiposFutbol.Entities;
using EquiposFutbol.DbContexts;
using Microsoft.EntityFrameworkCore;


namespace EquiposFutbol.Services
{
    public class TeamInfoRepository : ITeamInfoRepository
    {
        private readonly TeamInfoContext _context;

        public TeamInfoRepository(TeamInfoContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        public async Task<IEnumerable<Team>> GetTeamsAsync()
        {
            return await _context.Teams.OrderBy(c => c.Name).ToListAsync();
        }

        public async Task<bool> TeamNameMatchesTeamId(string? teamName, int teamId)
        {
            return await _context.Teams.AnyAsync(c => c.Id == teamId && c.Name == teamName);
        }

        public async Task<(IEnumerable<Team>, PaginationMetadata)> GetTeamsAsync(
            string? name, string? searchQuery, int pageNumber, int pageSize)
        {
            // collection to start from
            var collection = _context.Teams as IQueryable<Team>;

            if (!string.IsNullOrWhiteSpace(name))
            {
                name = name.Trim();
                collection = collection.Where(c => c.Name == name);
            }

            var totalItemCount = await collection.CountAsync();

            var paginationMetadata = new PaginationMetadata(
                totalItemCount, pageSize, pageNumber);

            var collectionToReturn = await collection.OrderBy(c => c.Name)
                .Skip(pageSize * (pageNumber - 1))
                .Take(pageSize)
                .ToListAsync();

            return (collectionToReturn, paginationMetadata);
        }



        public async Task<Team?> GetTeamAsync(int teamId, bool includePlayers)
        {
            if (includePlayers)
            {
                return await _context.Teams.Include(c => c.Players)
                    .Where(c => c.Id == teamId).FirstOrDefaultAsync();
            }

            return await _context.Teams
                  .Where(c => c.Id == teamId).FirstOrDefaultAsync();
        }

        public async Task<bool> TeamExistsAsync(int teamId)
        {
            return await _context.Teams.AnyAsync(c => c.Id == teamId);
        }

        public async Task<Player?> GetPlayerforTeamAsync(
            int teamId,
            int playerId)
        {
            return await _context.Players
               .Where(p => p.TeamId == teamId && p.Id == playerId)
               .FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<Player>> GetPlayerforTeamAsync(
            int teamId)
        {
            return await _context.Players
                           .Where(p => p.TeamId == teamId).ToListAsync();
        }

        public async Task AddPlayerforTeamAsync(int teamId,
            Player player)
        {
            var team = await GetTeamAsync(teamId, false);
            if (team != null)
            {
                team.Players.Add(player);
            }
        }

        public void DeletePlayer(Player player)
        {
            _context.Players.Remove(player);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return (await _context.SaveChangesAsync() >= 0);
        }
    }
}
