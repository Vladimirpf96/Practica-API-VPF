﻿using EquiposFutbol.Entities;

namespace EquiposFutbol.Services
{
    public interface ITeamInfoRepository
    {
        Task<IEnumerable<Team>> GetTeamsAsync();
        Task<(IEnumerable<Team>, PaginationMetadata)> GetTeamsAsync(
            string? name, string? searchQuery, int pageNumber, int pageSize);
        Task<Team?> GetTeamAsync(int teamId, bool includePlayers);
        Task<bool> TeamExistsAsync(int teamId);
        Task<IEnumerable<Player>> GetPlayerforTeamAsync(int cityId);
        Task<Player?> GetPlayerforTeamAsync(int teamId,
            int player);
        Task AddPlayerforTeamAsync(int teamId, Player player);
        void DeletePlayer(Player player);
        Task<bool> TeamNameMatchesTeamId(string? teamName, int teamId);
        Task<bool> SaveChangesAsync();
    }
}
