﻿using System.ComponentModel.DataAnnotations;

namespace EquiposFutbol.Models
{
    public class PlayerforCreation
    {
        [Required(ErrorMessage = "Debes proporcionar un nombre.")]
        [MaxLength(50)]
        public string Name { get; set; } = string.Empty;

        [MaxLength(200)]
        public string? Description { get; set; }
    }
}
