﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EquiposFutbol.Models
{
    public class TeamDto
    {
            /// <summary>
            /// The Id is required to identify the Team
            /// </summary>
            public int Id { get; set; }
            /// <summary>
            /// The name of the Team
            /// </summary>
            public string Name { get; set; }
            /// <summary>
            /// Collection of Players associated with a Team
            /// </summary>
            public ICollection<PlayerDto> Players { get; set; } = new List<PlayerDto>();
        }
    }



