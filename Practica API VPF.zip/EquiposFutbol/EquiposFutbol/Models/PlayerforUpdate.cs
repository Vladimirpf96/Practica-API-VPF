﻿using System.ComponentModel.DataAnnotations;

namespace EquiposFutbol.Models
{
    public class PlayerforUpdate
    {

        [Required(ErrorMessage = "Debes proporcionar un nombre.")]
        [MaxLength(255)]
        public string Name { get; set; } = string.Empty;

        
        [MaxLength(255)]
        public string? Description { get; set; }
    }
}
