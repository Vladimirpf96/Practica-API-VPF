﻿using EquiposFutbol.Entities;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EquiposFutbol.Models
{
    public class PlayerDto
    {
        /// <summary>
        /// Primary Key
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Player Name
        /// </summary>
        public string Name { get; set; }
        /// <summary>
        /// A simply description of the Player
        /// </summary>
        public string? Description { get; set; }
    }
}
