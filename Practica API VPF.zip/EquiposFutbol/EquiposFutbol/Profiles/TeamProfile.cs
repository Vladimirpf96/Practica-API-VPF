﻿using AutoMapper;

namespace EquiposFutbol.Profiles
{
    public class TeamProfile : Profile
    {
        public TeamProfile(){
        CreateMap<Entities.Team, Models.TeamWithoutPlayers>();
        CreateMap<Entities.Team, Models.TeamDto>();
        } 
    }
}
