﻿using AutoMapper;

namespace EquiposFutbol.Profiles
{
    public class Playerprofile : Profile
    {
        public Playerprofile()
        {
            CreateMap<Entities.Player, Models.PlayerDto>();
            CreateMap<Models.PlayerforCreation, Entities.Player>();
            CreateMap<Models.PlayerforUpdate, Entities.Player>();
            CreateMap<Entities.Player, Models.PlayerforUpdate>();
        }

    }
}
