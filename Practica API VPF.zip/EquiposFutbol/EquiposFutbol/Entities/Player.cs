﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace EquiposFutbol.Entities
{
    public class Player
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int Id { get; set; }

        [Required]
        [MaxLength(255)]
        public string Name { get; set; }

        [MaxLength(255)]
        public string? Description { get; set; }

        [ForeignKey("BrandId")]
        public Team? Team { get; set; }
        public int TeamId { get; set; }

        public Player(string name)
        {
            Name = name;
        }
    }
}
