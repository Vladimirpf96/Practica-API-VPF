﻿using EquiposFutbol.Entities;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;


namespace EquiposFutbol.DbContexts
{
    public class TeamInfoContext : DbContext
    {
        public DbSet<Team> Teams { get; set; } = null!;
        public DbSet<Player> Players { get; set; } = null!;

        public TeamInfoContext(DbContextOptions<TeamInfoContext> options)
        : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Team>().HasData(
                new Team("Real Madrid")
                {
                    Id = 1
                },
                new Team("FC Barcelona")
                {
                    Id = 2
                }
            );

            modelBuilder.Entity<Player>().HasData(
                new Player("Courtois")
                {
                    Id = 1,
                    TeamId = 1,
                    Description = "Portero Belga, internacional con su país,heroe en la 14"
                },
                new Player("Pedri")
                {
                    Id = 2,
                    TeamId = 2,
                    Description = "Joven jugador canario, estrella del equipo"
                }
            );

            base.OnModelCreating(modelBuilder);

        }

    }
}
